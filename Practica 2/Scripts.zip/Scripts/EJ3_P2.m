%% a) Estudio del experimento
close all;
subplot(), plot();
subplot(), plot();

%% b) Extrae la primera parte de los datos
Ts=; % Calculo el teimpo de muestreo 
t_fin=3.5; % Fijo el tiempo de corte
t_ini=1.5;% Fijo el tiempo de inicio

% Datos para freno al 0% 
t1a=t1(t_ini
u1a=u1(t_ini
y1a=y1(t_ini


%% c) Identifica las funci�n de transferencia

%% Datos para freno al 0%
close all;
subplot(), plot(); % Diagrama t1a-y1a
subplot(), plot(); % Diagrama t1a-u1a
% Calculamos la funci�n de transferencia por inspecci�n visual
k1=
tau1=
P1=



%% d) Validaci�n de resultados

%% Freno al 0%
y1ta= % Respuesta te�rica para la entrada u1a
subplot(),plot()

y1t=; % Respuesta te�rica para la entrada u1
subplot(),plot()



%% e) identificaci�n de la funci�n de transferencia
P1b=identifica_orden1(


%% f) Repetimos la identificaci�n para el segundo escal�n

t_fin=5.5; % Fijo el tiempo de corte
t_ini=3.5;% Fijo el tiempo de inicio

% Datos para freno al 0%
t1b=t1(
u1b=u1(
y1b=y1(
P1c=identifica_orden1(

% Pruebo solo para los dos �ltimos escalones
t_fin=7.5; % Fijo el tiempo de corte
t_ini=3.5;% Fijo el tiempo de inicio
t1c=t1(
u1c=u1(
y1c=y1(


y1tb=
subplot(),plot()
y1tb=
subplot(),plot()

%% g) Repetimos la identificaci�n para el resto de experimentos

%%Extrae la primera parte de los datos
% Datos para freno al 50 %
t2a =t2( t_ini ...
u2a =u2( t_ini ...
y2a =y2( t_in ...

% Datos para freno al 100 %
t3a =t3( t_ini ...
u3a =u3( t_ini ...
y3a =y3( t_ini ...

% Identificaci�n de funciones de transferencia
P2= identifica_orden1 ( ...
P3= identifica_orden1 ( ...

% Validaci�n de resultado
%% Freno al 50 %
y2ta = lsim ()
subplot (),plot ()

y2t = lsim ( )
subplot (),plot ()

%% Freno al 100 %
y3ta = lsim ();
subplot (),plot ()



