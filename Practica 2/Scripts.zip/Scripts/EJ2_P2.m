
%% EJERCICIO 2: SISTEMAS DE PRIMER ORDEN

%% a) Respuesta temporal para acciones de control b�sicas.
P=1/(s+1);
subplot(
subplot(
t=0:
u=
subplot(

%% b) Efecto de la ganancia en el comportamiento del sistema
close all
k= [8 4 
hold on
for i=
    
end
hold off

%% c) Efecto de la constante de tiempo en el comportamiento del sistema
close all
tau= [15 
hold on
for i
    
end
hold off

%% d) Efecto de los ceros en el comportamiento del sistema
close all
tau_c= [6 
hold on
for i=
    
end
hold off

% Repetimos para k=2
close all
tau_c= [6 
hold on
for i=
    
end
hold off


%% e) Definici�n de sistemas a partir de par�metros caracter�sticos
close all
% Caso 1 
k1=
tau1=
P1 = k1/(tau1*s+1);
step (P1)

% Caso 2 
k2=
tau2=
P2 = k2/(tau2*s+1);
step(P2)

% Caso 3 
k3=
tau3=
P3 = k3/(tau3*s+1);
step(P3)

% Caso 4 
k4=
tau4=
P4 = k4/(tau4*s+1);
step(P4)
