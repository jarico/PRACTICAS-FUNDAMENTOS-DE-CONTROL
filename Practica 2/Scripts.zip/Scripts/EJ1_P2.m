%% EJERCICIO 1: DEFINICI�N DE MODELOS LTI

%% a) Define las siguientes funciones de transferencia:
s=tf('s');
P1=
P2=
P3=

%% b) Realiza las siguientes operaciones:
% Obt�n los polos ceros y ganancia de P1 de tres formas distintas.
[ceros1,..

% Obt�n el numerador y el denominador de P2.
[num,den]=
    
% Diagrama de polos/ceros de P3
pz...


