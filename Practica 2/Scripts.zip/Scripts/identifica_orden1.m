function [P]=identifica_orden1(t,u,y)
% Identifica la funci�n de transferencia en funci�n de un experimento escal�n
% Requisitos:
%   - La se�al escal�n debe aplicase despues de al menos 0.25 segundos 
%   - La se�al de salid debe mantenerse en rp al menos 0.25 segundos

Ts= ;% Calculo el tiempo de muestreo 
n= ; % Calculo el numero de muestras 
Au= ;% Caluclo el incremento en la entrada

% Calculo la media del valor inicial y final
y_1=y(1:
y_ini=sum(

y_2=y(
y_fin=

Ay=;% Caluclo el incremento en la salida

k=; % Ganancia en r�gimen permanente

% Tiempo de inicio del experimento
c=2;
while u...
    
end

% Calculo la funci�n yrp-y(t)
e=


% Calculo la integral desde c hasta n
Ao=0;
for 
   
end

tau=
P=

