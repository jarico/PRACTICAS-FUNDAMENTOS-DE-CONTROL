%% Definici�n de funciones de transferencia
s=tf('s'); % Define la letra s como variable compleja
sys1=(s+1)/(s^2+2*s+4); % Define la FT empleando su ecuaci�n matem�tica

%sys=tf(num,den); % Define FT a partir de su numerador y denominador
% Ejemplo 1:
num=[1 1];
den=[1 2 4];
sys2=tf(num,den);

%sys=zpk(ceros,polos,ganancia); % Define la FT a partir de sus polos ceros y ganancia	
% Ejemplo 2:
ceros=[-2 -3 -4];
polos=[-1 ];
ganancia=2;
sys3=zpk(ceros,polos,ganancia);

% Ejemplos:
s=tf('s');
P1=tf([2 4],[1 1 2 3]); % Funci�n de transferencia creada mediante el comando TF
P2=zpk([-1 -2],[0 -4 -5 -7],[10]); % Formato ceros polos ganancia
P3=zpk([],[0 -4 -5 -7],[10]); 	% El conjunto vac�o indica que no existen ceros
P4=zpk([],[0],[1]);				% Funci�n de transferencia de un integrador
P5=1/s; 						% En este caso este formato es m�s sencillo	

%% Transposici�n entre modelos de representaci�n
sys_tf=P1;
sys_zpk=P2;

sys=zpk(sys_tf); 	% Guarda en sys el sistema sys_tf con formato  zpk
sys2=tf(sys_zpk); 	% Guarda en sys el sistema sys_zpk con formato num-den


[num,den]=tfdata(sys); 	% Guarda en num y den  el numerador y denominador de sys
[num,den]=tfdata(sys,'v');% Resultados en formato vector (no cell-array)

[z,p,k]=zpkdata(sys); 	% Guarda en z, p y k los  ceros, polos y ganancia de sys
[z,p,k]=zpkdata(sys,'v');% Resultados en formato vector (no cell-array) 

p=pole(sys); 			% Guarda en p los polos de sys
z=zero(sys);            % Guarda en z los ceros de sys
[z k]=zero(sys);		% Guarda en z y k los ceros y ganancia de sys

sys_min=minreal(sys); 	% Cancela polos y ceros para simplificar sys
% Ejemplo cancelaci�n polos/ceros
P=(s+1)/s/(s+1);
P_simp=minreal(P);


%% Representaci�n de diagramas polos-ceros
pzmap(sys); % Representa la situaci�n de polos y ceros de sys en el plano S
% Ejemplo:
G=tf([1 5 7 9],[4 5 8 7 9 3]);
pzmap(G)	


%% Respuesta temporal de los sistemas
sys=tf([2],[1 1]);
impulse (sys); % Representaci�n y c�lculo de la respuesta al impulso idealizado
step (sys); 	% Representaci�n y c�lculo de la respuesta al escal�n unitario

t=0:0.1:10; u=t;% u(t)=t;  rampa unitaria
lsim(sys,u,t); 	% Representaci�n y de la respuesta a una entrada arbitraria definida por u y t

%% Argumentos de entrada-salida adicionales en las funciones impulse, step, lsim

TFINAL= 8; 
sys2=tf([2],[1 1 1]);

impulse(sys);               % Grafica la respuesta al impulso del sistema sys. 
impulse(sys, TFINAL);       % Representa la respuesta impulsional desde t=0 hasta TFINAL
impulse(sys, t);            % Idem, pero utilizando el vector de tiempos t creado por el usuario
impulse(sys, sys2);         % Permite representar la respuesta de m�ltiples sistemas
impulse(sys, sys2,TFINAL);  % Idem, con acotaci�n de tiempo de evaluaci�n
impulse(sys, sys2, t);      % Idem, utilizando el vector de tiempo t
[y,t]=impulse(sys);         % Calcula los vectores de tiempo (t) y resultado (y) 
                            % Al llamarse la funci�n con argumentos de salida no representa ning�n gr�fico. 
[y,t]=impulse(sys, TFINAL); % Idem con definici�n de tiempo final de evaluaci�n
y = impulse(sys, t);        % Idem con vector de tiempo de usuario



%%

ltiview (sys);	% Llama al visor LTI para el an�lisis de sistemas LTI 
%Este permite analizar las respustas temporales, sus caracter�sticas, diagramas de Bode, Niquist, etc.

stepinfo(sys); % Obtenci�n de valores caracter�sticos a una entrada escal�n
lsiminfo(y,t); % Obtenci�n de valores caracter�sticos para una entrada aleatoria

tipo='square';
T=5;
[u,t]=gensig(tipo, T); 	% Generaci�n de se�ales de prueba (senoidal y cuadrada) 
                        % puede ser �til para generar las se�ales empleadas en lsim



