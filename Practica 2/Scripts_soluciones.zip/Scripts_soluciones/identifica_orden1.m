function [P]=identifica_orden1(t,u,y)
% Identifica la funci�n de transferencia en funci�n de un experimento escal�n
% Requisitos:
%   - La se�al escal�n debe aplicase despues de al menos 0.25 segundos 
%   - La se�al de salid debe mantenerse en rp al menos 0.25 segundos

Ts=t(2)-t(1);% Calculo el tiempo de muestreo 
n=length(u); % Calculo el numero de muestras 
Au=u(n)-u(1);% Caluclo el incremento en la entrada

% Calculo la media del valor inicial y final
y_1=y(1:floor(0.25/Ts));
y_ini=sum(y_1)/length(y_1);

y_2=y(n-floor(0.25/Ts):n);
y_fin=sum(y_2)/length(y_2);

Ay=y_fin-y_ini;% Caluclo el incremento en la salida

k=Ay/Au; % Ganancia en r�gimen permanente

% Tiempo de inicio del experimento
c=2;
while u(c)-u(c-1)==0
    c=c+1;
end

% Calculo la funci�n yrp-y(t)
e=y_fin-y;


% Calculo la integral desde c hasta n
Ao=0;
for i=c+1:n
    Ao=Ao+(e(i)+e(i-1))*Ts/2;
end

tau=Ao/k/Au;
P=tf(k,[tau 1]);

