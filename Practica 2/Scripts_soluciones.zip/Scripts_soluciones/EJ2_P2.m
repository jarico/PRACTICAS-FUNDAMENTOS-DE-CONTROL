
%% EJERCICIO 2: SISTEMAS DE PRIMER ORDEN

%% a) Respuesta temporal para acciones de control b�sicas.
P=1/(s+1);
subplot(3,1,1),impulse(P);
subplot(3,1,2),step(P);
t=0:0.1:10; 
u=t;
subplot(3,1,3),lsim(P,u,t);

%% b) Efecto de la ganancia en el comportamiento del sistema
close all
k= [8 4 2 1 0.5];
hold on
for i=1:length(k)
    step(tf(k(i),[1 1]));
end
hold off

%% c) Efecto de la constante de tiempo en el comportamiento del sistema
close all
tau= [15 10 5 1 0.5 ];
hold on
for i=1:length(tau)
    step(tf(1,[tau(i) 1]),100);
end
hold off

%% d) Efecto de los ceros en el comportamiento del sistema
close all
tau_c= [6 4 2  0.5 0.25 0.1];
hold on
for i=1:length(tau_c)
    step(tf([tau_c(i) 1],[1 1]));
end
hold off

% Repetimos para k=2
close all
tau_c= [6 4 2  0.5 0.25 0.1];
hold on
for i=1:length(tau_c)
    step(tf([2*tau_c(i) 2],[1 1]));
end
hold off


%% e) Definici�n de sistemas a partir de par�metros caracter�sticos
close all
% Caso 1 
k1=1;
tau1=10;
P1 = k1/(tau1*s+1);
step (P1)

% Caso 2 
k2=5;
tau2=8/4;% ts=4 tau
P2 = k2/(tau2*s+1);
step(P2)

% Caso 3 
k3=25;
tau3=k3/tand(80);% pendiente=k/tau
P3 = k3/(tau3*s+1);
step(P3)

% Caso 4 
k4=10;
tau4=0.22/2.2;% tl=2.2tau
P4 = k4/(tau4*s+1);
step(P4)
