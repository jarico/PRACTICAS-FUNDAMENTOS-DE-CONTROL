%% a) Estudio del experimento
close all;
subplot(2,1,1), plot(t1,y1,t2,y2,t3,y3);
subplot(2,1,2), plot(t1,u1,t2,u2,t3,u3);

%% b) Extrae la primera parte de los datos
Ts=t1(2)-t1(1); % Calculo el teimpo de muestreo 
t_fin=3.5; % Fijo el tiempo de corte
t_ini=1.5;% Fijo el tiempo de inicio

%% c) Identifica la funci�n de transferencia

%% Datos para freno al 0%
close all;
subplot(2,1,1), plot(t1a,y1a); % Diagrama t1a-y1a
subplot(2,1,2), plot(t1a,u1a); % Diagrama t1-y1
% Calculamos las plantas por inspecci�n visual
k1=650/2; % Regimen permanente / incremento en la entrada
tau1=0.15; % Busco el tiempo en el que se alcanza 0.63yrp 0.65-0.5=0.15
P1=tf(k1,[tau1 1]);

%% d) Validaci�n de resultados

%% Freno al 0%
y1ta=lsim(P1,u1a,t1a);
subplot(2,1,1),plot(t1a,y1a,t1a,y1ta)

y1t=lsim(P1,u1,t1);
subplot(2,1,2),plot(t1,y1,t1,y1t)


%% e) identificaci�n de la funci�N de transferencia
P1b=identifica_orden1(t1a,u1a,y1a);


%% f) Repetimos la identificaci�n para el segundo escal�n

t_fin=5.5; % Fijo el tiempo de corte
t_ini=3.5;% Fijo el tiempo de inicio

% Datos para freno al 0%
t1b=t1(t_ini/Ts+1:t_fin/Ts+1)-t_ini;
u1b=u1(t_ini/Ts+1:t_fin/Ts+1)-u1(t_ini/Ts+1);
y1b=y1(t_ini/Ts+1:t_fin/Ts+1)-y1(t_ini/Ts+1);
P1c=identifica_orden1(t1b,u1b,y1b);

% Pruebo solo para los dos �ltimos escalones
t_fin=7.5; % Fijo el tiempo de corte
t_ini=3.5;% Fijo el tiempo de inicio
t1c=t1(t_ini/Ts+1:t_fin/Ts+1)-t_ini;
u1c=u1(t_ini/Ts+1:t_fin/Ts+1)-u1(t_ini/Ts+1);
y1c=y1(t_ini/Ts+1:t_fin/Ts+1)-y1(t_ini/Ts+1);


y1tb=lsim(P1c,u1b,t1b);
subplot(2,1,1),plot(t1b,y1b,t1b,y1tb)
y1tb=lsim(P1c,u1c,t1c);
subplot(2,1,2),plot(t1c,y1c,t1c,y1tb)


%% g) Repetimos la identificaci�n para el resto de experimentos

%%Extrae la primera parte de los datos
% Datos para freno al 50%
t2a=t2(t_ini/Ts:t_fin/Ts)-t_ini;
u2a=u2(t_ini/Ts:t_fin/Ts);
y2a=y2(t_ini/Ts:t_fin/Ts);

% Datos para freno al 100%
t3a=t3(t_ini/Ts:t_fin/Ts)-t_ini;
u3a=u3(t_ini/Ts:t_fin/Ts);
y3a=y3(t_ini/Ts:t_fin/Ts);

% Identificaci�n de funciones de transferencia
P2=identifica_orden1(t2a,u2a,y2a);
P3=identifica_orden1(t3a,u3a,y3a);

% Identificaci�n de funciones de transferencia
%% Freno al 50%
y2ta=lsim(P2,u2a,t2a);
subplot(2,1,1),plot(t2a,y2a,t2a,y2ta)

y2t=lsim(P2,u2,t2);
subplot(2,1,2),plot(t2,y2,t2,y2t)

%% Freno al 100%
y3ta=lsim(P3,u3a,t3a);
subplot(2,1,1),plot(t3a,y3a,t3a,y3ta)

y3t=lsim(P3,u3,t3);
subplot(2,1,2),plot(t3,y3,t3,y3t)


