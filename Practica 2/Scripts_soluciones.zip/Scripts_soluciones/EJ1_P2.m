%% EJERCICIO 1: DEFINICI�N DE MODELOS LTI

%% a) Define las siguientes funciones de transferencia:
s=tf('s');
P1=tf([1 2 1],[1 4 0 2 1]);
P2=zpk([-1 -4],[0 -2 -7 -9],5);
P3=10*s/(s^2+2*s+2)/(s+3);

%% b) Realiza las siguientes operaciones:
% Obt�n los polos ceros y ganancia de P1 de tres formas distintas.
[ceros,polos,ganancia]=zpkdata(P1,'v');
polos2=pole(P1);
[ceros2, ganancia2]=zero(P1);

% Obt�n el numerador y el denominador de P2.
[num2, den2]=tfdata(P2,'v');
pzmap(P3)

