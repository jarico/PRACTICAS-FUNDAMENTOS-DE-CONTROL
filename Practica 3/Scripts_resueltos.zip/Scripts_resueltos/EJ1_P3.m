%%
prec=3;
formato='%2.2f';
%% EJERCICIO 1
%% a) Respuesta temporal para acciones de control b�sicas.
k=1;
d=0.4;
wn=1;
s=tf('s'); % Define la letra s como variable compleja
P=k*wn^2/(s^2+2*d*wn*s+wn^2);
subplot(3,1,1),impulse(P);
subplot(3,1,2),step(P);
t=0:0.1:10; 
u=t;
subplot(3,1,3),lsim(P,u,t);

%% b) Efecto de la ganancia en el comportamiento del sistema
close all
k= [0.5 1 2 4 8];
hold on
for i=1:length(k)
    step(tf(k(i)*wn^2,[1 2*d*wn wn^2]));
    legendInfo{i} = ['k = ' num2str(k(i))];
end
legend(legendInfo)

hold off

figure
hold on
for i=1:length(k)
    pzmap(tf(k(i)*wn^2,[1 2*d*wn wn^2]));
end
legend(legendInfo); 
hold off

%% c) Efecto del amortiguamiento relativo en el comportamiento del sistema
close all
k=1;
d=0.1:0.2:0.9;
wn=1;
hold on
for i=1:length(d)
    step(tf(k*wn^2,[1 2*d(i)*wn wn^2]));
    legendInfo{i} = ['d = ' num2str(d(i))]; 
end
legend(legendInfo)
hold off

figure
hold on
for i=1:length(d)
    pzmap(tf(k*wn^2,[1 2*d(i)*wn wn^2]));
end
legend(legendInfo); 
hold off

%% d) Efecto de la pulsaci�n natural en el comportamiento del sistema
close all
k=1;
d=0.4;
wn=1:1:6;
hold on
for i=1:length(wn)
    step(tf(k*wn(i)^2,[1 2*d*wn(i) wn(i)^2]));
    legendInfo{i} = ['wn = ' num2str(wn(i))]; 
end
legend(legendInfo); 
title ('Respuesta al escal�n con k=1, d=0.4, wn=1:1:6')
hold off

figure
hold on
for i=1:length(wn)
    pzmap(tf(k*wn(i)^2,[1 2*d*wn(i) wn(i)^2]));
end
legend(legendInfo);
title ('Polos con k=1, d=0.4, wn=1:1:6')
hold off

%% e) Envolventes
close all
k=1;
d=0.4;
wn=1;
p=tf(k*wn^2,[1 2*d*wn wn^2]);
[y,t]=step(p);
ya=1+exp(-t.*d*wn)./sqrt(1-d.^2);
yb=1-exp(-t.*d*wn)./sqrt(1-d.^2);
plot(t,y,'b',t,ya,'--k',t,yb,'--k');
title ('Envolventes')

%% f) Parte real constante
close all
k=1;
d=0.3:0.1:0.6;
wn=1./d;
hold on
for i=1:length(wn)
    step(tf(k*wn(i)^2,[1 2*d(i)*wn(i) wn(i)^2]));
      legendInfo{i} = [' k= 1, wn = ' num2str(wn(i), formato) ', d = ' num2str(d(i), formato)];
end
legend(legendInfo); 
hold off

figure
hold on
for i=1:length(wn)
    pzmap(tf(k*wn(i)^2,[1 2*d(i)*wn(i) wn(i)^2]));
end
legend(legendInfo); 
hold off


% Envolventes 
figure
colori=['b', 'g','m','r']
hold on
t=0:0.1:10;
for i=1:length(wn)
    y=1+exp(-t.*d(i)*wn(i))./sqrt(1-d(i).^2);
    plot(t,y,'color',colori(i));
end
legend(legendInfo);
yt=1+exp(-t);
plot(t,yt,'k')
legendInfo{(i+1)} = ['envolvente para calc. ts'];
legend(legendInfo); 
hold off


%% g) Efecto de los ceros en el comportamiento del sistema
close all
k=1;
d=0.4;
wn=1;
tau_c=1:0.5:4;

hold on
for i=1:length(tau_c)
    p=k*wn^2*(tau_c(i)*s+1)/(s^2+ 2*d*wn*s +wn^2);
    step(p)
    legendInfo{i} = ['tau_c = ' num2str(tau_c(i))]; 
end
p=k*wn^2/(s^2+ 2*d*wn*s +wn^2);
step(p,'k*');
legendInfo{(i+1)} = ['Sistema sin cero a�adido'];
legend(legendInfo); 
hold off

figure
hold on
for i=1:length(tau_c)
    p=k*wn^2*(tau_c(i)*s+1)/(s^2+ 2*d*wn*s +wn^2);
    pzmap(p)
end
legend(legendInfo(1:i)); 
hold off