%% EJERCICIO 3

%% CONTROLADOR I
%% a) Estudio matem�tico de la respuesta en lazo cerrado
clear;
close all;
s=tf('s');
p=350/(0.16*s+1);
ki=(0:0.001:0.01);

hold on
for i=1:length(ki)
    c=ki(i)/s;
    m=feedback(c*p,1);
    pzmap(m);
end


%% b) Respuesta temporal para acciones de control b�sicas.
close all
load datos_controlador_I

subplot(2,1,1),plot(t,y_ki_3,t,r,'k--');
% Trrazo la banda de tolerancia
t2=[5 8];
BT_s=[1 1]*(1500+0.02*500);
BT_i=[1 1]*(1500-0.02*500);
hold on
plot(t2,BT_s,'r:',t2,BT_i,'r:');
title('Respuesta para un escal�n 1000->1500 rpm')
legend('velocidad', 'referencia', 'BT 2%')
hold off

ylabel('Velocidad del rotor [rpm]')
xlabel('Tiempo [s]')
axis([4 8 900 1800])
subplot(2,1,2),plot(t,u_ki_3);
ylabel('Accion de control [V]')
xlabel('Tiempo [s]')
axis([4 8 2 6])


%% bb) Respuesta temporal para acciones de control b�sicas.
% Trazo de las enolventes  Eliminado del enunciado
close all
load datos_controlador_I

subplot(2,1,1),plot(t,y_ki_3,t,r,'k--');
% Trrazo la banda de tolerancia y la envolvente
t2=[5 8];
BT_s=[1 1]*(1500+0.02*500);
BT_i=[1 1]*(1500-0.02*500);

t3=5:0.01:8;
tau=0.16;
k=350;
ki=0.03;
d=1/2/sqrt(tau*k*ki);
env1=500*(1-exp(-(t3-5)/2/tau)/sqrt(1-d^2))+1000;
env2=500*(1+exp(-(t3-5)/2/tau)/sqrt(1-d^2))+1000;
hold on
plot(t2,BT_s,':r',t3,env1,'g',t2,BT_i,':r',t3,env2,'g');
title('Respuesta para un escal�n 1000->1500 rpm')
legend('velocidad', 'referencia', 'BT 2%', 'Envolvente')
hold off

ylabel('Velocidad del rotor [rpm]')
xlabel('Tiempo [s]')
axis([4 8 900 1800])
subplot(2,1,2),plot(t,u_ki_3);
ylabel('Accion de control [V]')
xlabel('Tiempo [s]')
axis([4 8 2 6])


%% c) Estudio de la respuesta temporal para ki=4

% Calculo los par�metros de la respuesta te�rica de lazo cerrado
k=350;
tau=0.16;
ki=0.03;

d=1/2/sqrt(ki*k*tau);
wn=sqrt(k*ki/tau);

RM=100*exp(-d*pi/sqrt(1-d^2));
ymax=1500+500*RM/100;
disp('Valor m�ximo en la respuesta' );
disp(ymax);

tp=pi/wn/sqrt(1-d^2);
disp('Tiempo de pico')
disp(5+tp);


% Valores obtenidos del la figura 
% ymax= 1713
% tp= 5.33


%% d) Caomparativa entre el sistema real y el te�rico

s=tf('s');
ki=0.03;
p=350/(0.16*s+1);
c=ki/s;
m=feedback(p*c,1);
[yt,tt]=step(500*m,3);
tt=tt+4.98;
yt=yt+1000;
figure
subplot(2,1,1),plot(t,y_ki_3,tt, yt,t,r,'k--');
title('Comparativa entre el modelo y el sistema real')
legend('Real', 'Modelo', 'Referencia')
ylabel('Velocidad del rotor [rpm]')
xlabel('Tiempo [s]')
axis([4 8 900 1800])

c=ki/s;
mu=c/(1+p*c);
[ut,tt]=step(500*mu,3);
tt=tt+4.98;
ut=ut+u_ki_3(1);
subplot(2,1,2),plot(t,u_ki_3, tt, ut );
legend('Real', 'Modelo')
ylabel('Accion de control [V]')
xlabel('Tiempo [s]')
axis([4 8 2 6])



%% e) Respuesta real obtenida para todos los valores de ki
close all
subplot(2,1,1),plot(t,[y_ki_1 y_ki_2 y_ki_3 y_ki_4 y_ki_5],t,r,'k--');
legend('ki=0.01','ki=0.02','ki=0.03','ki=0.04','ki=0.05')
ylabel('Velocidad del rotor [rpm]')
xlabel('Tiempo [s]')
axis([4 8 900 1800])
subplot(2,1,2),plot(t,[u_ki_1 u_ki_2 u_ki_3 u_ki_4 u_ki_5]);
legend('ki=0.01','ki=0.02','ki=0.03','ki=0.04','ki=0.05')
ylabel('Accion de control [V]')
xlabel('Tiempo [s]')
axis([4 8 2 6])



%% CONTROLADOR PI
%% f) Estudio matem�tico de la respuesta en lazo cerrado
clear;
close all;
s=tf('s');
p=350/(0.15*s+1);
ki=0.03;
kp=(0:0.001:0.01);

hold on
for i=1:length(kp)
    c=kp(i)+ki/s;
    m=feedback(c*p,1);
    m=minreal(m/(kp(i)*s+ki));
    pzmap(m);
end

%% g) Respuesta temporal para acciones de control b�sicas.
close all
% Respuesta real
subplot(2,1,1),plot(t,y_pi_1,t,r,'k--');
title('Respuesta del sistema con ki=0.03 kp=0.001')
legend('velocidad','referencia')
ylabel('Velocidad del rotor [rpm]')
xlabel('Tiempo [s]')
axis([4 8 900 1800])
subplot(2,1,2),plot(t,u_pi_1);
ylabel('Accion de control [V]')
xlabel('Tiempo [s]')
axis([4 8 2 5])

% Comparativa Real-Te�rico
s=tf('s');
ki=0.03;
kp=0.001;
p=350/(0.15*s+1);
c=ki/s+kp;
m=feedback(p*c,1);
[yt,tt]=step(500*m,3);
tt=tt+4.98;
yt=yt+1000;
figure
subplot(2,1,1),plot(t,y_pi_1,tt, yt,t,r,'k--');
title('Comparativa entre el modelo y el sistema real')
legend('Real', 'Modelo', 'Referencia')
ylabel('Velocidad del rotor [rpm]')
xlabel('Tiempo [s]')
axis([4 8 900 1800])

mu=c/(1+p*c);
[ut,tt]=step(500*mu,3);
tt=tt+4.98;
ut=ut+u_pi_1(1);
subplot(2,1,2),plot(t,u_pi_1,tt,ut);
legend('Real', 'Modelo')
ylabel('Accion de control [V]')
xlabel('Tiempo [s]')
axis([4 8 2 6])

%% h) Respuesta real obtenida para todos los controladores PI

subplot(2,1,1),plot(t,[y_pi_1 y_pi_15 y_pi_2],t,r,'k--');
title('Respuesta para los diferentes PI')
legend('kp=0.001','ki=0.0015','ki=0.002')
ylabel('Velocidad del rotor [rpm]')
xlabel('Tiempo [s]')
axis([4 8 900 1800])
subplot(2,1,2),plot(t,[u_pi_1 u_pi_15 u_pi_2 ]);
ylabel('Accion de control [V]')
xlabel('Tiempo [s]')
axis([4 8 2 6])


%% i) Respuesta ante perturbaciones.
load datos_perturbaciones 
close all
figure
subplot(2,1,1),plot(t,y1,t,r,'k--');
legend('velocidad','referencia')
title('Perturbaci�n constante 0->50%')
ylabel('Velocidad del rotor [rpm]')
xlabel('Tiempo [s]')
axis([2.5 8 700 1200])
subplot(2,1,2),plot(t,u1);
ylabel('Accion de control [V]')
xlabel('Tiempo [s]')
axis([2.5 8 2 6])

figure
subplot(2,1,1),plot(t,y2,t,r,'k--');
legend('velocidad','referencia')
title('Perturbaci�n 0%->50%->0%')
ylabel('Velocidad del rotor [rpm]')
xlabel('Tiempo [s]')
axis([2.5 8 700 1200])
subplot(2,1,2),plot(t,u2);
ylabel('Accion de control [V]')
xlabel('Tiempo [s]')
axis([2.5 8 2 4])