%% EJERCICIO 2

%% a) Aproximaci�n por una din�mica de segundo orden.
close all
s=tf('s');
%a=5;
%P=10/(s/a+1)/(s^2+s+2);
Pa2=10/(s^2+s+2);
polosPa2 =pole(Pa2);
a=-10*real(polosPa2(1)); 
P=10/(s/a+1)/(s^2+s+2);
pzmap(P);
P2=10/(s^2+s+2);
figure
step(P,P2)

%% b) Efecto del polo real en la aproximaci�n.
close all
a=[1  2 3  4 5];
hold on
for i=1:length(a)
	step(10/(s/a(i)+1)/(s^2+s+2));
    legendInfo{i} = ['con polo a�adido = -' num2str(a(i))]; 
end

step(P2,'k*')
legendInfo{(i+1)} = ['Sistema sin polo a�adido'];
legend(legendInfo); 
hold off


figure
hold on
for i=1:length(a)
    pzmap(10/(s/a(i)+1)/(s^2+s+2))
    legendInfo{i} = ['con polo a�adido = -' num2str(a(i))]; 
end
legend(legendInfo);
hold off
%% c) Aproximaci�n por una din�mica de primer orden.
a=0.05;
P=10/(s/a+1)/(s^2+s+2);
P3=5/(s/a+1);

step(P,P3)
legend(('P=10/(s/0.05+1)/(s^2+s+2)'), 'P3=5/(s/0.05+1)')

%% d) Efecto del polo real en la aproximaci�n.
close all
a=[0.1 0.2 0.3 0.4  0.5];
colores=['r' 'g' 'b' 'c' 'm' 'y' 'k'];
hold on
for i=1:length(a)
    step(10/(s/a(i)+1)/(s^2+s+2),colores(i));
    legendInfo{i} = ['con polo a�adido = -' num2str(a(i))]; 
end

for i=1:length(a)
    aux=strcat('--',colores(i));
    step(5/(s/a(i)+1),aux)
    legendInfo{i+length(a)} = ['Sist 1er orden con polo = -' num2str(a(i))]; 
end
legend(legendInfo); 
hold off


