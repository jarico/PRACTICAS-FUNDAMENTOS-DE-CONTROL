%%
prec=3;
%% EJERCICIO 1
%% a) Respuesta temporal para acciones de control b�sicas.
k=1;
d=0.4;
wn=1;
s=tf('s'); % Define la letra s como variable compleja
P=k*wn^2/(s^2+2*d*wn*s+wn^2);
subplot(3,1,1),impulse(P);
subplot(3,1,2),step(P);
t=0:0.1:10; 
u=t;
subplot(3,1,3),lsim(

%% b) Efecto de la ganancia en el comportamiento del sistema
close all
k= 
hold on
for i=1:
    step(tf(
    legendInfo{i} = ['k = ' num2str(k(i))];
end
legend(legendInfo)

hold off

figure
hold on
for i=1:
    pzmap(
end
legend(legendInfo); 
hold off

%% c) Efecto del amortiguamiento relativo en el comportamiento del sistema
close all
k=1;
d=
wn=1;
hold on
for i=1:
    step(
    legendInfo{i} = 
end
legend(legendInfo)
hold off

figure
hold on
for i=1:
    pzmap(tf(
end
legend(legendInfo); 
hold off

%% d) Efecto de la pulsaci�n natural en el comportamiento del sistema
close all
k=1;
d=0.4;
wn=
hold on
for i=1:
    step(
    legendInfo{i} = ['wn = ' num2str(wn(i))]; 
end
legend(legendInfo); 
title ('Respuesta al escal�n con k=1, d=0.4, wn=1:1:6')
hold off

figure
hold on
for i=1:length(wn)
    pzmap(tf(k*wn(i)^2,[1 2*d*wn(i) wn(i)^2]));
end
legend(legendInfo);
title ('Polos con k=1, d=0.4, wn=1:1:6')
hold off

%% e) Envolventes
close all
k=1;
d=0.4;
wn=1;
p=tf(k*wn^2,[1 2*d*wn wn^2]);
[y,t]=
ya=1+exp(-t.*d*wn)./sqrt(1-d.^2);
yb=
plot(t,y,'b',t,ya,'--k',t,yb,'--k');
title ('Envolventes')

%% f) Parte real constante
formato='%2.2f';
close all
k=1;
d=0.3:0.1:0.6;
wn=1./d;
hold on
for i=1:
    step
    legendInfo{i} = [' k= 1, wn = ' num2str(wn(i), formato) ', d = ' num2str(d(i), formato)];
end
legend(legendInfo); 
hold off

figure
hold on
for i=1:
    pzmap(
end
legend(legendInfo); 
hold off


% Envolventes 
figure
colori=['b', 'g','m','r'];
hold on
t=0:0.1:10;
for i=1:length(wn)
    y=
    plot(t,y,'color',colori(i));
end
legend(legendInfo);
yt=
plot(t,yt,'k')
legendInfo{(i+1)} = ['envolvente para calc. ts'];
legend(legendInfo); 
hold off


%% g) Efecto de los ceros en el comportamiento del sistema
close all
k=1;
d=0.4;
wn=1;
tau_c=1:0.5:4;

hold on
for i=1:length(tau_c)
    p=
    step(p)
    legendInfo{i} = ['tau_c = ' num2str(tau_c(i))]; 
end
p=
step(
legendInfo{(i+1)} = ['Sistema sin cero a�adido'];
legend(legendInfo); 
hold off

figure
hold on
for i=1:
    p=
    pzmap(p)
end
legend(legendInfo(1:i)); 
hold off