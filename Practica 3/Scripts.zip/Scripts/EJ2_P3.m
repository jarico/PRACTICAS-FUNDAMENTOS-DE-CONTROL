%% EJERCICIO 2

%% a) Aproximaci�n por una din�mica de segundo orden.
close all
s=tf('s');
Pa2=10/(s^2+s+2);
polosPa2 =pole(Pa2);
a=
P=
pzmap(P);
P2=10/(s^2+s+2);
figure
step(P,P2)

%% b) Efecto del polo real en la aproximaci�n.
close all
a=
hold on
for i=1:
	step(
    legendInfo{i} = ['con polo a�adido = -' num2str(a(i))]; 
end

step(P2,'k*')
legendInfo{(i+1)} = ['Sistema sin polo a�adido'];
legend(legendInfo); 
hold off


figure
hold on
for i=1:
    pzmap(
    legendInfo{i} = ['con polo a�adido = -' num2str(a(i))]; 
end
legend(legendInfo);
hold off
%% c) Aproximaci�n por una din�mica de primer orden.
a=0.05;
P=
P3=

step(P,P3)
legend(('P=10/(s/0.05+1)/(s^2+s+2)'), 'P3=5/(s/0.05+1)')

%% d) Efecto del polo real en la aproximaci�n.
close all
a=[0.1 0.2 0.3 0.4  0.5];
colores=['r' 'g' 'b' 'c' 'm' 'y' 'k'];
hold on
for i=1:
    step
    legendInfo{i} = ['con polo a�adido = -' num2str(a(i))]; 
end

for i=1:
    aux=strcat('--',colores(i));
    
    legendInfo{i+length(a)} = ['Sist 1er orden con polo = -' num2str(a(i))]; 
end
legend(legendInfo); 
hold off


